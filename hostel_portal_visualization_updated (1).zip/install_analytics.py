from pathlib import Path
import re, shutil
from datetime import datetime

ROOT = Path.cwd()
APP = ROOT / "hostel_app"
CSV_FILE = ROOT / "data" / "Occupancy_Estimation.csv"

if not (ROOT / "manage.py").exists():
    raise SystemExit("Run this script from the hostel_portal_fixed folder containing manage.py.")
if not APP.exists():
    raise SystemExit("hostel_app folder not found; no files changed.")
if not CSV_FILE.exists():
    raise SystemExit("data/Occupancy_Estimation.csv not found; no files changed.")

def backup(path):
    if path.exists():
        target = path.with_name(path.name + ".backup_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        shutil.copy2(path, target)
        print("Backup:", target.relative_to(ROOT))

view_path = APP / "analytics_views.py"
template_path = APP / "templates" / "analytics.html"
template_path.parent.mkdir(parents=True, exist_ok=True)

view_code = '''import csv
from collections import Counter, defaultdict
from pathlib import Path
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def analytics_dashboard(request):
    csv_path = Path(settings.BASE_DIR) / "data" / "Occupancy_Estimation.csv"
    counts = Counter()
    hourly = defaultdict(lambda: {"temp": [], "co2": []})
    temps, co2s = [], []
    total = 0

    with csv_path.open("r", newline="", encoding="utf-8-sig") as file:
        for row in csv.DictReader(file):
            total += 1
            try:
                counts[int(float(row.get("Room_Occupancy_Count", 0)))] += 1
            except (TypeError, ValueError):
                pass
            hour = (row.get("Time") or "")[:2]
            try:
                value = float(row.get("S1_Temp", ""))
                temps.append(value)
                hourly[hour]["temp"].append(value)
            except (TypeError, ValueError):
                pass
            try:
                value = float(row.get("S5_CO2", ""))
                co2s.append(value)
                hourly[hour]["co2"].append(value)
            except (TypeError, ValueError):
                pass

    hours = sorted(h for h in hourly if h.isdigit())
    average = lambda values: round(sum(values) / len(values), 2) if values else None
    chart_data = {
        "hours": [h + ":00" for h in hours],
        "temperature": [average(hourly[h]["temp"]) for h in hours],
        "co2": [average(hourly[h]["co2"]) for h in hours],
        "occupancy_labels": ["0 people", "1 person", "2 people", "3 people"],
        "occupancy_counts": [counts.get(i, 0) for i in range(4)],
    }
    return render(request, "analytics.html", {
        "total_rows": total,
        "avg_temp": average(temps) or 0,
        "avg_co2": average(co2s) or 0,
        "chart_data": chart_data,
    })
'''

template_code = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Hostel Occupancy Analytics</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{--ink:#202644;--muted:#697386;--line:#e6e9f2;--accent:#5146e5}
*{box-sizing:border-box}body{margin:0;background:#f5f7fc;color:var(--ink);font-family:Segoe UI,Arial,sans-serif}
header{padding:30px clamp(18px,4vw,52px);background:linear-gradient(120deg,#24265f,#6258ef);color:white}
.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:1.5px;opacity:.8;font-weight:700}
h1{margin:8px 0;font-size:clamp(26px,4vw,36px)}header p{margin:0;opacity:.9}
main{max-width:1200px;margin:24px auto;padding:0 18px 36px}
.note{background:#fff8e7;border:1px solid #f2dfa6;border-radius:12px;padding:14px 16px;font-size:13px;line-height:1.5;margin-bottom:18px}
.stats,.charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.stats{grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:16px}
.stat,.panel{background:white;border:1px solid var(--line);border-radius:16px;padding:20px;box-shadow:0 5px 18px #17255408;min-width:0}
.label{color:var(--muted);font-size:13px}.value{font-size:30px;font-weight:750;margin-top:8px}.foot,.panel p{font-size:12px;color:var(--muted);line-height:1.5}
.panel h2{font-size:17px;margin:0 0 5px}.panel p{margin:0 0 14px}.chart{height:285px;position:relative}.wide{grid-column:1/-1}
.insight{margin-top:16px;padding:14px 16px;background:#efefff;border-left:4px solid var(--accent);border-radius:0 10px 10px 0;font-size:13px;line-height:1.6}
a{display:inline-block;margin-top:20px;color:var(--accent);font-weight:650;text-decoration:none}footer{text-align:center;padding:0 16px 26px;color:var(--muted);font-size:12px}
@media(max-width:760px){.stats,.charts{grid-template-columns:1fr}.wide{grid-column:auto}.chart{height:250px}}
</style></head>
<body>
<header><div class="eyebrow">Hostel Management System · FT-IV Visualization</div><h1>Occupancy Analytics</h1><p>Interactive exploration of room sensor readings</p></header>
<main>
<div class="note"><b>Dataset note:</b> These charts use the sample Occupancy Estimation sensor dataset. They are demonstration analytics and do not represent actual hostel students or room assignments.</div>
<section class="stats">
<div class="stat"><div class="label">Sensor observations</div><div class="value">{{ total_rows }}</div><div class="foot">CSV rows analysed</div></div>
<div class="stat"><div class="label">Average S1 temperature</div><div class="value">{{ avg_temp }} °C</div><div class="foot">Across valid sensor readings</div></div>
<div class="stat"><div class="label">Average CO₂ reading</div><div class="value">{{ avg_co2 }}</div><div class="foot">S5_CO2 sensor units as supplied</div></div>
</section>
<section class="charts">
<article class="panel"><h2>Occupancy category distribution</h2><p>Count of observations in each estimated occupancy class.</p><div class="chart"><canvas id="occupancy"></canvas></div></article>
<article class="panel"><h2>Average temperature by hour</h2><p>Hourly average of S1_Temp in degrees Celsius.</p><div class="chart"><canvas id="temperature"></canvas></div></article>
<article class="panel wide"><h2>Average CO₂ reading by hour</h2><p>Hourly average of the S5_CO2 sensor reading.</p><div class="chart"><canvas id="co2"></canvas></div><div class="insight"><b>Evaluation insight:</b> The bar chart compares a categorical variable (occupancy class). The line charts show numerical sensor measurements grouped by hour, making daily patterns easier to compare than plotting every raw row.</div></article>
</section>
<a href="/">← Back to Hostel Dashboard</a>
</main><footer>Built with Django, Python's built-in CSV module and Chart.js · Sample sensor data only</footer>
{{ chart_data|json_script:"chart-data" }}
<script>
const d=JSON.parse(document.getElementById("chart-data").textContent);
const common={responsive:true,maintainAspectRatio:false,scales:{x:{grid:{display:false}},y:{beginAtZero:true,grid:{color:"rgba(120,130,150,.16)"}}}};
new Chart(document.getElementById("occupancy"),{type:"bar",data:{labels:d.occupancy_labels,datasets:[{label:"Observations",data:d.occupancy_counts,backgroundColor:["#c7d2fe","#a5b4fc","#818cf8","#5146e5"],borderRadius:7,maxBarThickness:55}]},options:{...common,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>" "+c.raw.toLocaleString()+" observations"}}},scales:{...common.scales,y:{...common.scales.y,title:{display:true,text:"Number of observations"}}}}});
new Chart(document.getElementById("temperature"),{type:"line",data:{labels:d.hours,datasets:[{label:"Average temperature (°C)",data:d.temperature,borderColor:"#5146e5",backgroundColor:"rgba(81,70,229,.12)",fill:true,tension:.28,pointRadius:3}]},options:{...common,plugins:{legend:{display:true,position:"bottom"}},scales:{...common.scales,y:{...common.scales.y,title:{display:true,text:"Temperature (°C)"}}}}});
new Chart(document.getElementById("co2"),{type:"line",data:{labels:d.hours,datasets:[{label:"Average S5_CO2",data:d.co2,borderColor:"#0f9f8f",backgroundColor:"rgba(15,159,143,.1)",fill:true,tension:.28,pointRadius:3}]},options:{...common,plugins:{legend:{display:true,position:"bottom"}},scales:{...common.scales,y:{...common.scales.y,title:{display:true,text:"Average S5_CO2 reading"}}}}});
</script></body></html>
'''

backup(view_path)
view_path.write_text(view_code, encoding="utf-8")
backup(template_path)
template_path.write_text(template_code, encoding="utf-8")
print("Created analytics view and template.")

app_urls = APP / "urls.py"
root_urls = ROOT / "hostel_project" / "urls.py"
if not root_urls.exists():
    root_urls = ROOT / "urls.py"

if app_urls.exists():
    target = app_urls
    import_line = "from .analytics_views import analytics_dashboard"
else:
    target = root_urls
    import_line = "from hostel_app.analytics_views import analytics_dashboard"

if not target.exists():
    raise SystemExit("Analytics files were created, but URL configuration was not found. Send me your urls.py file.")
content = target.read_text(encoding="utf-8")
if "analytics_dashboard" not in content:
    backup(target)
    if "from django.urls import" not in content or not re.search(r"urlpatterns\s*=\s*\[", content):
        raise SystemExit("Analytics files were created, but URL file format was unusual. Send me its contents.")
    content = import_line + "\n" + content
    match = re.search(r"urlpatterns\s*=\s*\[", content)
    pos = match.end()
    content = content[:pos] + "\n    path('analytics/', analytics_dashboard, name='analytics')," + content[pos:]
    target.write_text(content, encoding="utf-8")
    print("Added /analytics/ route to", target.relative_to(ROOT))
else:
    print("Analytics route already appears to exist in", target.relative_to(ROOT))

print("\nInstall step finished. Next run:")
print("python manage.py check")
print("python manage.py runserver")
print("Then sign in and open http://127.0.0.1:8000/analytics/")
